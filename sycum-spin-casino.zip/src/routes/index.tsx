import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useRef, useState } from "react";
import { Coins, Crown, Dices, Sparkles } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sycum Spin Casino — Spin the Golden Wheel" },
      {
        name: "description",
        content:
          "Sycum Spin Casino: spin the golden wheel, stack play credits and chase the 50x jackpot. Free to play, just for fun.",
      },
      { property: "og:title", content: "Sycum Spin Casino — Spin the Golden Wheel" },
      {
        property: "og:description",
        content:
          "Spin the golden wheel, stack play credits and chase the 50x jackpot at Sycum Spin Casino.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type Segment = { label: string; multiplier: number; color: string };

const SEGMENTS: Segment[] = [
  { label: "x2", multiplier: 2, color: "oklch(0.3 0.06 285)" },
  { label: "x0.5", multiplier: 0.5, color: "oklch(0.24 0.05 285)" },
  { label: "x1.5", multiplier: 1.5, color: "oklch(0.62 0.21 10)" },
  { label: "x1", multiplier: 1, color: "oklch(0.24 0.05 285)" },
  { label: "x5", multiplier: 5, color: "oklch(0.82 0.16 85)" },
  { label: "x0.5", multiplier: 0.5, color: "oklch(0.24 0.05 285)" },
  { label: "x3", multiplier: 3, color: "oklch(0.3 0.06 285)" },
  { label: "x1", multiplier: 1, color: "oklch(0.24 0.05 285)" },
  { label: "x1.5", multiplier: 1.5, color: "oklch(0.62 0.21 10)" },
  { label: "x0.5", multiplier: 0.5, color: "oklch(0.24 0.05 285)" },
  { label: "x50", multiplier: 50, color: "oklch(0.72 0.17 160)" },
  { label: "x1", multiplier: 1, color: "oklch(0.24 0.05 285)" },
];

const SLICE = 360 / SEGMENTS.length;
const BETS = [10, 25, 50, 100];

function wheelBackground() {
  const stops = SEGMENTS.map((s, i) => `${s.color} ${i * SLICE}deg ${(i + 1) * SLICE}deg`);
  return `conic-gradient(from ${-SLICE / 2}deg, ${stops.join(", ")})`;
}

function Index() {
  const [credits, setCredits] = useState(500);
  const [bet, setBet] = useState(25);
  const [angle, setAngle] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [message, setMessage] = useState("Place your bet and spin the wheel.");
  const [history, setHistory] = useState<string[]>([]);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const spin = useCallback(() => {
    if (spinning || credits < bet) return;
    setSpinning(true);
    setCredits((c) => c - bet);
    setMessage("The wheel is turning…");

    const index = Math.floor(Math.random() * SEGMENTS.length);
    const target = 360 * 6 - index * SLICE;
    setAngle((prev) => prev + (target - (prev % 360)) + 360);

    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      const seg = SEGMENTS[index]!;
      const win = Math.round(bet * seg.multiplier);
      setCredits((c) => c + win);
      setMessage(
        seg.multiplier >= 50
          ? `JACKPOT! ${seg.label} pays ${win} credits!`
          : seg.multiplier < 1
            ? `${seg.label} — a small return of ${win} credits.`
            : `${seg.label} — you won ${win} credits.`,
      );
      setHistory((h) => [seg.label, ...h].slice(0, 8));
      setSpinning(false);
    }, 4200);
  }, [bet, credits, spinning]);

  return (
    <main className="min-h-screen px-5 pb-20 pt-8 sm:px-8">
      <header className="mx-auto flex max-w-5xl items-center justify-between">
        <div className="flex items-center gap-2">
          <Crown className="size-7 text-primary" />
          <span className="font-display text-xl font-bold tracking-widest text-gold sm:text-2xl">
            SYCUM SPIN
          </span>
        </div>
        <div className="flex items-center gap-2 rounded-full border border-border bg-card/70 px-4 py-2 shadow-card backdrop-blur">
          <Coins className="size-4 text-primary" />
          <span className="text-sm font-semibold tabular-nums">{credits}</span>
          <span className="text-xs text-muted-foreground">credits</span>
        </div>
      </header>

      <section className="mx-auto mt-10 max-w-2xl text-center">
        <p className="inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-3 py-1 text-xs uppercase tracking-[0.2em] text-muted-foreground">
          <Sparkles className="size-3 text-primary" /> Play money only
        </p>
        <h1 className="mt-5 text-4xl font-black leading-tight sm:text-6xl">
          <span className="text-gold">Spin the golden wheel</span>
        </h1>
        <p className="mx-auto mt-4 max-w-md text-sm text-muted-foreground sm:text-base">
          Every spin pays something — one jackpot worth 50x your stake. Every credit here is for fun.
        </p>
      </section>

      <section className="mx-auto mt-12 flex max-w-xl flex-col items-center">
        <div className="relative">
          <div
            aria-hidden
            className="absolute -top-3 left-1/2 z-10 size-0 -translate-x-1/2 border-x-[14px] border-t-[26px] border-x-transparent"
            style={{ borderTopColor: "oklch(0.9 0.13 95)" }}
          />
          <div className="rounded-full bg-gold p-[6px] shadow-glow">
            <div
              className="size-[300px] rounded-full border-4 border-background sm:size-[380px]"
              style={{
                background: wheelBackground(),
                transform: `rotate(${angle}deg)`,
                transition: "transform 4s cubic-bezier(0.17, 0.72, 0.1, 1)",
              }}
            />
          </div>
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <div className="flex size-20 items-center justify-center rounded-full bg-card shadow-card ring-2 ring-primary/60 sm:size-24">
              <Dices className={spinning ? "size-8 animate-spin text-primary" : "size-8 text-primary"} />
            </div>
          </div>
        </div>

        <p className="mt-8 min-h-6 text-center text-sm font-medium text-foreground/90">{message}</p>

        <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
          {BETS.map((b) => (
            <button
              key={b}
              onClick={() => setBet(b)}
              disabled={spinning}
              className={
                "rounded-full border px-5 py-2 text-sm font-semibold transition-colors disabled:opacity-50 " +
                (bet === b
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-card/70 text-foreground hover:bg-secondary")
              }
            >
              {b}
            </button>
          ))}
        </div>

        <button
          onClick={spin}
          disabled={spinning || credits < bet}
          className="mt-6 w-full max-w-xs rounded-full bg-gold px-8 py-4 font-display text-lg font-bold uppercase tracking-widest text-primary-foreground shadow-glow transition-transform hover:scale-[1.02] disabled:scale-100 disabled:opacity-50 animate-pulse-glow"
        >
          {spinning ? "Spinning…" : credits < bet ? "Out of credits" : `Spin for ${bet}`}
        </button>

        {credits < bet && !spinning && (
          <button
            onClick={() => {
              setCredits(500);
              setMessage("Balance topped up to 500 play credits.");
            }}
            className="mt-3 text-xs uppercase tracking-widest text-muted-foreground underline underline-offset-4 hover:text-primary"
          >
            Reset balance
          </button>
        )}

        {history.length > 0 && (
          <div className="mt-10 flex flex-wrap items-center justify-center gap-2">
            <span className="text-xs uppercase tracking-widest text-muted-foreground">Last spins</span>
            {history.map((h, i) => (
              <span
                key={i}
                className="rounded-md border border-border bg-card/70 px-2 py-1 text-xs font-semibold tabular-nums"
              >
                {h}
              </span>
            ))}
          </div>
        )}
      </section>

      <footer className="mx-auto mt-20 max-w-xl text-center text-xs text-muted-foreground">
        Sycum Spin is a free entertainment game. No real money, no payouts, 18+.
      </footer>
    </main>
  );
}
